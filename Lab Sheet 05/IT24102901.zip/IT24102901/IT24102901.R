getwd()
setwd("C:\\Users\\VICTUS\\OneDrive\\Desktop\\IT24102901")

##Q1
delivery_times<-read.table("Exercise - Lab 05.txt",header=TRUE,sep=",")
fix(delivery_times)
attach(delivery_times)

names(delivery_times)<-c("del_time")

##Q2
histogram2<-hist(del_time, main="Histogram for Deliver Times",breaks=seq(20,70,length=9),right=FALSE)

##Q4
breaks2 <- round(histogram2$breaks)
freq2 <- histogram2$counts
mids2 <- histogram2$mids

classes2<-c()

for(i in 1:length(breaks2)-1){
  classes2[i]<-paste0("[",breaks2[i], ",", breaks2[i+1], ")")
}

cbind(Classes=classes2, Frequency=freq2)

lines(mids2,freq2)

plot(mids2, freq2, type = 'l', main = "Frequency Polygon for Deliver Time",xlab = "Delivery Time", ylab = "Frequency", ylim=c(0,max(freq2)))

