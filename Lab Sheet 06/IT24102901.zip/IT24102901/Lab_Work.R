getwd()
setwd("C:\\Users\\VICTUS\\OneDrive\\Desktop\\IT24102901")

dbinom(40, 44, 0.92)
pbinom(35, 44, 0.92,lower.tail = TRUE)

1- pbinom(37, 44, 0.92,lower.tail = TRUE)

pbinom(35, 44, 0.92,lower.tail = FALSE)

pbinom(42, 44, 0.92,lower.tail = TRUE)-pbinom(39, 44, 0.92,lower.tail = TRUE)

dpois(5,6)
ppois(6,5,lower.tail=FALSE)
