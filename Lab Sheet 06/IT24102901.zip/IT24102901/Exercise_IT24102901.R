getwd()

#Exercise
#Q1

# i) Binomial Distribution bin(50, 0.85)

#ii)
1- pbinom(46, 50, 0.85, lower.tail = TRUE)

#Q2

#i) Number of calls received on a given hour.
#ii) Poisson Distribution
#iii)

dpois(15,12)
