getwd()
setwd("C:\\Users\\it24102901\\Desktop\\IT24102901")

df<-read.table('Exercise - LaptopsWeights.txt', header = TRUE)
fix(df)
attach(df)

#Q1
popmean<-mean(Weight.kg.)
popmean

popsd<-sd(Weight.kg.)
popsd

#Q2
samples<-c()
n<-c()

for(i in 1:25){
  s<- sample(Weight.kg.,6,replace = TRUE)
  samples<-cbind(samples, s)
  n<-c(n,paste('S',i))
}

colnames(samples)=n

s.means<-apply(samples,2,mean)
s.means
s.deviations<-apply(samples,2,sd)
s.deviations

#Q3
samplemeans<-mean(s.means)
samplemeans

sampledeviation<-sd(s.deviations)
sampledeviation

popmean
samplemeans

popsd
sampledeviation